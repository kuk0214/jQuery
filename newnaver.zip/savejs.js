	$('#year').blur(function() {
		var year = $('#year').val();
		var yearPattern = /^[0-9]{4}$/;
		if(year == '' || !yearPattern.test(year)) {
			$('span').filter('.error_box').eq(4).css('display', 'block');
			$('span').filter('.error_box').eq(4).html('태어난 년도를 4자리를 정확하게 입력하세요')
		} else {
			monthcheck();
		}
			
		function monthcheck() {
			var month = $('select:first').val();
			if(month === 'month') {
				$('span').filter('.error_box').eq(4).css('display', 'block');
				$('span').filter('.error_box').eq(4).html('태어난 월을 선택하세요');
			}
			 
			$('#sel_month').blur(function() {
					daycheck();
			});
		} 
		
		function daycheck() {
			var day = $('#int_day').val();
			var dayPattern = /^\d{1,2}$/;
			if(day == '') {
						$('span').filter('.error_box').eq(4).css('display', 'block');
						$('span').filter('.error_box').eq(4).html('태어난 일(날짜) 2자리를 정확하게 입력하세요.');
			} 
			
			$('#int_day').blur(function() {
				if(dayPattern.test(day)) {
					if(Number(day) < 1 || Number(day) > 31) {
						$('span').filter('.error_box').eq(4).css('display', 'block');
						$('span').filter('.error_box').eq(4).html('생년월일을 다시 확인해주세요.');
					} else {
						bdatecheck()
					}
				}
			});
			
		}
		
		function bdatecheck() {
			if(Number(year) < 1922) {
				$('span').filter('.error_box').eq(4).css('display', 'block');
				$('span').filter('.error_box').eq(4).html('정말이세요?');
			} else {
				$('span').filter('.error_box').eq(4).css('display', 'none');
			}
		}
	});	