$(document).ready(function() {
	$('input, div, select').focus(function() {
		$(this).parent().css('border', '1px solid #03c75a');
	});
	$('input, div, select').blur(function() {
		$(this).parent().css('border', '1px solid lightgrey');
	});
	
	
	$('#id').blur(function() {
		var sid = $('#id').val();
		var idPattern = /^[a-z0-9][a-z0-9-_]{4,19}$/;
		if(sid ==='') {
			$('span').filter('.error_box').eq(0).css('display', 'block');
			$('span').filter('.error_box').eq(0).css('color', 'red');
			$('span').filter('.error_box').eq(0).html('필수정보 입니다.');
			
		} else {
			if(!idPattern.test(sid)) {
				$('span').filter('.error_box').eq(0).css('display', 'block');
				$('span').filter('.error_box').eq(0).css('color', 'red');
				$('span').filter('.error_box').eq(0).html('5~20자의 영문 소문자, 숫자와 특수기호(_),(-)만 사용 가능합니다.');
			} else {
				$('span').filter('.error_box').eq(0).css('display', 'block');
				$('span').filter('.error_box').eq(0).css('color', '#08a600');
				$('span').filter('.error_box').eq(0).html('멋진 아이디네요!');
			}
		}
	});
	
	$('#pw').blur(function() {
		var pwPattern = /^(?=.*[a-z])(?=.*[0-9])[a-zA-Z0-9~!@#$%^&*()_+|<>?:{}]{8,16}$/
		if($('#pw').val() === '') {
			$('span').filter('.error_box').eq(1).css('display', 'block');
			$('span').filter('.error_box').eq(1).html('필수정보 입니다.');
			$('#pw_ck').attr('src', 'm_icon_pass.png')
			$('#img_text').css('display', 'none');
		} else {
			if(!pwPattern.test($('#pw').val())) {
				$('span').filter('.error_box').eq(1).css('display', 'block');
				$('span').filter('.error_box').eq(1).html('8~16자 영문 대 소문자, 숫자, 특수문자를 사용하세요.');
				$('#img_text').css('display', 'inline-block');
				$('#img_text').css('color', 'red');
				$('#img_text').html('사용불가');
				$('#pw_ck').attr('src', 'm_icon_not_use.png')
			} else {
				$('span').filter('.error_box').eq(1).css('display', 'none');
				$('#img_text').css('color', '#08a600');
				$('#img_text').css('margin-left', '50px');
				$('#img_text').css('display', 'inline-block');
				$('#img_text').html('안전');
				$('#pw_ck').attr('src', 'm_icon_safe.png')
			}
		}
	});
	
	$('#repw').blur(function() {
		if($('#repw').val() === '') {
			$('span').filter('.error_box').eq(2).css('display', 'block');
			$('span').filter('.error_box').eq(2).html('필수정보 입니다.');
			$('#repw_ck').attr('src', 'm_icon_check_disable.png')
		} else {
			if($('#pw').val() !== $('#repw').val() && $('#repw').val() !== '') {
				$('span').filter('.error_box').eq(2).css('display', 'block');
				$('span').filter('.error_box').eq(2).css('color', 'red');
				$('span').filter('.error_box').eq(2).html('비밀번호가 일치하지 않습니다.');
			} else {
				$('#repw_ck').attr('src', 'm_icon_check_enable.png')
				$('span').filter('.error_box').eq(2).css('display', 'none');
			}
		}
	});
	
	$('#pw').focus(function() {
		$('#pw').keydown(function() {
					$('span').filter('.error_box').eq(1).css('display', 'none');
		});
	});
	
	$('#repw').blur(function() {
		if($('#repw').val() === '') {
			$('span').filter('.error_box').eq(2).css('display', 'block');
			$('span').filter('.error_box').eq(2).html('필수정보 입니다.');
		}
	});
	
	$('#name').blur(function() {
		if($('#name').val() === '') {
			$('span').filter('.error_box').eq(3).css('display', 'block');
		}
	});
	
	$('#year').blur(function() {
		var year = $('#year').val();
		var yearPattern = /^[0-9]{4}$/;
		if(year == '' || !yearPattern.test(year)) {
			$('span').filter('.error_box').eq(4).css('display', 'block');
			$('span').filter('.error_box').eq(4).html('태어난 년도를 4자리를 정확하게 입력하세요')
		} else {
			monthcheck();
		}
			
		function monthcheck() {
			var month = $('select:first').val();
			if(month === 'month') {
				$('span').filter('.error_box').eq(4).css('display', 'block');
				$('span').filter('.error_box').eq(4).html('태어난 월을 선택하세요');
			}
			 
			$('#sel_month').blur(function() {
					daycheck();
			});
		} 
		
		function daycheck() {
			var day = $('#int_day').val();
			var dayPattern = /^\d{1,2}$/;
			if(day == '') {
						$('span').filter('.error_box').eq(4).css('display', 'block');
						$('span').filter('.error_box').eq(4).html('태어난 일(날짜) 2자리를 정확하게 입력하세요.');
			} 
			
			$('#int_day').blur(function() {
				if(dayPattern.test(day)) {
					if(Number(day) < 1 || Number(day) > 31) {
						$('span').filter('.error_box').eq(4).css('display', 'block');
						$('span').filter('.error_box').eq(4).html('생년월일을 다시 확인해주세요.');
					} else {
						bdatecheck
					}
				}
			});
			
		}
		
		function bdatecheck() {
			if(Number(year) < 1922) {
				$('span').filter('.error_box').eq(4).css('display', 'block');
				$('span').filter('.error_box').eq(4).html('정말이세요?');
			} else {
				$('span').filter('.error_box').eq(4).css('display', 'none');
			}
		}
	});	
});